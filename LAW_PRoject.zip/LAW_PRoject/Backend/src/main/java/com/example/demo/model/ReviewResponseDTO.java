package com.example.demo.model;
import lombok.Data;

@Data
public class ReviewResponseDTO {
  private String response;
}

